<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
</head>
<body>
    <h1>Welcome to the Department of CSE</h1>
    <a href="timetable.php">Timetable</a>
</body>
</html>
